package types

import (
	"github.com/cosmos/cosmos-sdk/types"
)

const (
	DefaultCodespace types.CodespaceType = ModuleName
)
