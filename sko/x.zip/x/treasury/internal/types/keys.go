package types

const (
	ModuleName   = "treasury"
	StoreKey     = ModuleName
	RouterKey    = ModuleName
	QuerierRoute = ModuleName
)
