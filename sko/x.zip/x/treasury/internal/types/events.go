package types

const (
	AttributeValueCategory = ModuleName
)
