

# Darkpool 客户端 The second part

RPC remote port by cosmos

https://cosmos.network/rpc/v0.38.3

