# Treasury module specification

## Contents

1. **[Messages](01_messages.md)**
    - [MsgSend](01_messages.md#msgsend)
    - [MsgOracleTransfer](01_messages.md#msgoracletransfer)
    - [MsgOracleMint](01_messages.md#msgoraclemint)
    - [MsgOracleBurn](01_messages.md#msgoracleburn)
