package types

import "github.com/cosmos/cosmos-sdk/codec"

// ModuleCdc is the codec for the module.
var ModuleCdc = codec.New()

func init() {
	RegisterCodec(ModuleCdc)
	channel.RegisterCodec(ModuleCdc)
	commitmenttypes.RegisterCodec(ModuleCdc)
	oracle.RegisterCodec(ModuleCdc)
}

// RegisterCodec registers concrete types on the Amino codec.
func RegisterCodec(cdc *codec.Codec) {
	cdc.RegisterConcrete(MsgSetSourceChannel{}, "goldcdp/SetSourceChannel", nil)
	cdc.RegisterConcrete(MsgBuyGold{}, "goldcdp/BuyGold", nil)
}
